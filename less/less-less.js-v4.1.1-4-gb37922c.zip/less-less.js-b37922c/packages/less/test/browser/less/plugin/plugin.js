
functions.add('func', function() {
    return less.anonymous(location.href);
});
