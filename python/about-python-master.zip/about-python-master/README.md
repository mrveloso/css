# about-python
Unresponsive website recreation of the below image for Coding Dojo.
![About Python](http://s3.amazonaws.com/General_V88/boomyeah/company_209/chapter_3921/handouts/chapter3921_7093_python-BSD.png)
